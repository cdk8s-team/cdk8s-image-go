export declare function shell(command: string, ...args: string[]): string;
